# revised login form

A Pen created on CodePen.io. Original URL: [https://codepen.io/daljeet/pen/nBMgvz](https://codepen.io/daljeet/pen/nBMgvz).

please view in full screen....just made a few changes in original code to make it look cool....hope anyone wont mind..
link to original code...http://codepen.io/hugo/pen/ypcqb